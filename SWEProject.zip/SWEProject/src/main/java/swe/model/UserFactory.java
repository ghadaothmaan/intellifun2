package swe.model;

public class UserFactory {
	
	
	
}
